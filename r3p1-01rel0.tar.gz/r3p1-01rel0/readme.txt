CONFIG=release VARIANT=mali400-gles11-gles20-linux-ump TOOLCHAIN=gcc make


